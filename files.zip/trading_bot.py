"""
Bot de trading BTC/ETH - Signaux d'achat/vente par SMS
========================================================

Ce bot tourne en continu (24h/24), analyse BTC et ETH toutes les 15 minutes
via l'API publique de Binance (aucune clé API requise pour lire les prix),
et t'envoie un SMS quand un signal d'achat ou de vente apparaît.

IMPORTANT - AVERTISSEMENT :
Ceci n'est PAS un conseil financier. Les indicateurs techniques ne
prédisent pas le futur, ils décrivent seulement le passé récent. Un signal
"achat" peut être suivi d'une baisse. Ne trade jamais avec de l'argent
que tu ne peux pas te permettre de perdre, et considère ce bot comme un
outil d'aide à la décision, pas un système automatique de trading (il
n'envoie que des notifications, il n'achète/vend rien tout seul).

CONFIGURATION REQUISE (voir section CONFIG plus bas) :
1. Un compte Twilio (https://www.twilio.com/try-twilio) - gratuit au début,
   te donne un numéro d'envoi + des identifiants (Account SID, Auth Token)
2. Ton numéro de cellulaire pour recevoir les SMS

INSTALLATION :
    pip install requests twilio --break-system-packages

LANCEMENT :
    python3 trading_bot.py

Pour que ça tourne 24h/24, il faut l'héberger sur une machine toujours
allumée (voir README.md fourni avec ce script pour les options).
"""

import os
import time
import logging
import requests
from datetime import datetime, timezone

# ============================================================
# CONFIG
# ============================================================
# Les identifiants Twilio sont lus depuis les variables d'environnement
# (à définir dans l'onglet "Variables" de Railway) plutôt qu'écrits en
# clair ici, puisque ce fichier sera sur un GitHub public.

TWILIO_ACCOUNT_SID = os.environ.get("TWILIO_ACCOUNT_SID")
TWILIO_AUTH_TOKEN = os.environ.get("TWILIO_AUTH_TOKEN")
TWILIO_FROM_NUMBER = os.environ.get("TWILIO_FROM_NUMBER")
MY_PHONE_NUMBER = os.environ.get("MY_PHONE_NUMBER")

SYMBOLS = ["BTCUSDT", "ETHUSDT"]
CHECK_INTERVAL_SECONDS = 15 * 60      # analyse toutes les 15 minutes
KLINE_INTERVAL = "1h"                 # bougies de 1h pour les indicateurs
KLINE_LIMIT = 250                     # nb de bougies à récupérer (besoin de 200+ pour SMA200)

RSI_PERIOD = 14
RSI_OVERSOLD = 30     # en dessous = signal potentiel d'achat
RSI_OVERBOUGHT = 70   # au-dessus = signal potentiel de vente

VOLUME_SPIKE_MULTIPLIER = 2.5  # volume 2.5x la moyenne = anormal

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
log = logging.getLogger("tradingbot")

# Mémorise le dernier signal envoyé par symbole pour ne pas spammer
last_signal_sent = {symbol: None for symbol in SYMBOLS}


# ============================================================
# RÉCUPÉRATION DES DONNÉES (API publique Binance, sans clé)
# ============================================================

def fetch_klines(symbol, interval=KLINE_INTERVAL, limit=KLINE_LIMIT):
    url = "https://api.binance.com/api/v3/klines"
    params = {"symbol": symbol, "interval": interval, "limit": limit}
    resp = requests.get(url, params=params, timeout=15)
    resp.raise_for_status()
    raw = resp.json()
    closes = [float(c[4]) for c in raw]
    volumes = [float(c[5]) for c in raw]
    return closes, volumes


# ============================================================
# INDICATEURS TECHNIQUES (calculés à la main, sans dépendance lourde)
# ============================================================

def sma(values, period):
    if len(values) < period:
        return None
    return sum(values[-period:]) / period


def ema_series(values, period):
    if len(values) < period:
        return []
    k = 2 / (period + 1)
    ema = [sum(values[:period]) / period]
    for price in values[period:]:
        ema.append(price * k + ema[-1] * (1 - k))
    return ema


def compute_rsi(closes, period=RSI_PERIOD):
    if len(closes) < period + 1:
        return None
    gains, losses = [], []
    for i in range(1, len(closes)):
        diff = closes[i] - closes[i - 1]
        gains.append(max(diff, 0))
        losses.append(max(-diff, 0))
    avg_gain = sum(gains[:period]) / period
    avg_loss = sum(losses[:period]) / period
    for i in range(period, len(gains)):
        avg_gain = (avg_gain * (period - 1) + gains[i]) / period
        avg_loss = (avg_loss * (period - 1) + losses[i]) / period
    if avg_loss == 0:
        return 100
    rs = avg_gain / avg_loss
    return 100 - (100 / (1 + rs))


def compute_macd(closes, fast=12, slow=26, signal=9):
    if len(closes) < slow + signal:
        return None, None
    ema_fast = ema_series(closes, fast)
    ema_slow = ema_series(closes, slow)
    diff_len = min(len(ema_fast), len(ema_slow))
    macd_line = [ema_fast[-diff_len:][i] - ema_slow[-diff_len:][i] for i in range(diff_len)]
    signal_line = ema_series(macd_line, signal)
    if not signal_line:
        return None, None
    return macd_line[-1] - macd_line[-2], signal_line[-1] - (signal_line[-2] if len(signal_line) > 1 else signal_line[-1])


def compute_macd_cross(closes, fast=12, slow=26, signal=9):
    """Retourne 'bull', 'bear' ou None selon le dernier croisement MACD/signal."""
    if len(closes) < slow + signal + 2:
        return None
    ema_fast = ema_series(closes, fast)
    ema_slow = ema_series(closes, slow)
    diff_len = min(len(ema_fast), len(ema_slow))
    macd_line = [ema_fast[-diff_len:][i] - ema_slow[-diff_len:][i] for i in range(diff_len)]
    signal_line = ema_series(macd_line, signal)
    if len(signal_line) < 2:
        return None
    macd_aligned = macd_line[-len(signal_line):]
    prev_diff = macd_aligned[-2] - signal_line[-2]
    curr_diff = macd_aligned[-1] - signal_line[-1]
    if prev_diff <= 0 and curr_diff > 0:
        return "bull"
    if prev_diff >= 0 and curr_diff < 0:
        return "bear"
    return None


def detect_volume_spike(volumes, lookback=20, multiplier=VOLUME_SPIKE_MULTIPLIER):
    if len(volumes) < lookback + 1:
        return False
    avg_vol = sum(volumes[-lookback - 1:-1]) / lookback
    return volumes[-1] > avg_vol * multiplier


def compute_ma_cross(closes):
    """Retourne 'golden' (bullish) ou 'death' (bearish) si croisement SMA50/SMA200."""
    if len(closes) < 201:
        return None
    sma50_now = sma(closes, 50)
    sma200_now = sma(closes, 200)
    sma50_prev = sma(closes[:-1], 50)
    sma200_prev = sma(closes[:-1], 200)
    if None in (sma50_now, sma200_now, sma50_prev, sma200_prev):
        return None
    if sma50_prev <= sma200_prev and sma50_now > sma200_now:
        return "golden"
    if sma50_prev >= sma200_prev and sma50_now < sma200_now:
        return "death"
    return None


# ============================================================
# LOGIQUE DE DÉCISION
# ============================================================

def analyze_symbol(symbol):
    closes, volumes = fetch_klines(symbol)
    rsi = compute_rsi(closes)
    macd_cross = compute_macd_cross(closes)
    ma_cross = compute_ma_cross(closes)
    vol_spike = detect_volume_spike(volumes)
    price = closes[-1]

    buy_reasons, sell_reasons = [], []

    if rsi is not None:
        if rsi < RSI_OVERSOLD:
            buy_reasons.append(f"RSI survendu ({rsi:.1f})")
        elif rsi > RSI_OVERBOUGHT:
            sell_reasons.append(f"RSI suracheté ({rsi:.1f})")

    if macd_cross == "bull":
        buy_reasons.append("croisement MACD haussier")
    elif macd_cross == "bear":
        sell_reasons.append("croisement MACD baissier")

    if ma_cross == "golden":
        buy_reasons.append("golden cross (SMA50 > SMA200)")
    elif ma_cross == "death":
        sell_reasons.append("death cross (SMA50 < SMA200)")

    if vol_spike:
        # Le sens du spike de volume dépend de la direction du prix récent
        if closes[-1] > closes[-2]:
            buy_reasons.append("pic de volume haussier")
        else:
            sell_reasons.append("pic de volume baissier")

    signal = None
    if len(buy_reasons) >= 2:
        signal = ("BUY", buy_reasons)
    elif len(sell_reasons) >= 2:
        signal = ("SELL", sell_reasons)

    return signal, price


# ============================================================
# ENVOI DE SMS (Twilio)
# ============================================================

def send_sms(message):
    try:
        from twilio.rest import Client
        client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)
        client.messages.create(body=message, from_=TWILIO_FROM_NUMBER, to=MY_PHONE_NUMBER)
        log.info(f"SMS envoyé : {message}")
    except Exception as e:
        log.error(f"Échec de l'envoi du SMS : {e}")


# ============================================================
# BOUCLE PRINCIPALE
# ============================================================

def run():
    missing = [
        name for name, val in [
            ("TWILIO_ACCOUNT_SID", TWILIO_ACCOUNT_SID),
            ("TWILIO_AUTH_TOKEN", TWILIO_AUTH_TOKEN),
            ("TWILIO_FROM_NUMBER", TWILIO_FROM_NUMBER),
            ("MY_PHONE_NUMBER", MY_PHONE_NUMBER),
        ] if not val
    ]
    if missing:
        log.error(
            "Variables d'environnement manquantes: %s. "
            "Définis-les dans l'onglet Variables de Railway avant de relancer.",
            ", ".join(missing),
        )
        return

    log.info("Bot de trading démarré. Analyse toutes les %d minutes.", CHECK_INTERVAL_SECONDS // 60)
    while True:
        for symbol in SYMBOLS:
            try:
                signal, price = analyze_symbol(symbol)
                if signal:
                    action, reasons = signal
                    if last_signal_sent[symbol] != action:
                        msg = (
                            f"[{symbol}] Signal {action} @ {price:,.2f} USD\n"
                            f"Raisons : {', '.join(reasons)}\n"
                            f"{datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}"
                        )
                        send_sms(msg)
                        last_signal_sent[symbol] = action
                    else:
                        log.info(f"[{symbol}] Signal {action} déjà notifié, on n'envoie pas de doublon.")
                else:
                    log.info(f"[{symbol}] Aucun signal clair (prix: {price:,.2f})")
            except Exception as e:
                log.error(f"Erreur en analysant {symbol}: {e}")
        time.sleep(CHECK_INTERVAL_SECONDS)


if __name__ == "__main__":
    run()
